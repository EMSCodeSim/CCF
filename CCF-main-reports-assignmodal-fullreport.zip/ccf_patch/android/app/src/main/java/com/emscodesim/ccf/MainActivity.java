package com.emscodesim.ccf;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
